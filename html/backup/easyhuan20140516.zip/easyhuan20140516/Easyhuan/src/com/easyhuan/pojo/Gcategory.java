package com.easyhuan.pojo;

public class Gcategory {
	private Integer gcategoryId;
	private String gcategoryName;

	public Gcategory() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getGcategoryId() {
		return gcategoryId;
	}

	public void setGcategoryId(Integer gcategoryId) {
		this.gcategoryId = gcategoryId;
	}

	public String getGcategoryName() {
		return gcategoryName;
	}

	public void setGcategoryName(String gcategoryName) {
		this.gcategoryName = gcategoryName;
	}

}
